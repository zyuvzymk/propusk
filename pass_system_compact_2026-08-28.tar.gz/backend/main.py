from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from database import engine, Base
from routes import public  # Импортируем наш созданный модуль

# Автоматически создаем таблицы в базе данных при старте
try:
    Base.metadata.create_all(bind=engine)
    print(" База данных успешно инициализирована, таблицы созданы.")
except Exception as e:
    print(f" Ошибка инициализации базы данных: {e}")

app = FastAPI(title="Система пропусков Поморской Судоверфи", version="1.0.0")

# Учим FastAPI отдавать файлы из папки static по адресу /static
app.mount("/static", StaticFiles(directory="static"), name="static")

# Подключаем роутер приема публичных заявок
app.include_router(public.router)

templates = Jinja2Templates(directory="templates")

# ==============================================================================
# НАВИГАЦИЯ ПО ШАБЛОНАМ (ОТДАЧА HTML СТРАНИЦ)
# ==============================================================================

@app.get("/", response_class=HTMLResponse)
@app.get("/index.html", response_class=HTMLResponse)
async def read_index(request: Request):
    """Главная страница - Форма подачи заявки контрагентами"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login.html", response_class=HTMLResponse)
async def read_login(request: Request):
    """Страница авторизации пользователей админки"""
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/dashboard.html", response_class=HTMLResponse)
async def read_dashboard(request: Request):
    """Реестр заявок для ПЕПа, ДАВа и Охраны"""
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/view.html", response_class=HTMLResponse)
async def read_view(request: Request):
    """Детальный просмотр конкретного пропуска и управление им"""
    return templates.TemplateResponse("view.html", {"request": request})
