from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import EmailStr

class Settings(BaseSettings):
    # Настройки PostgreSQL
    DB_USER: str
    DB_PASSWORD: str
    DB_NAME: str
    DB_HOST: str
    DB_PORT: int

    # Настройки портов
    BACKEND_PORT: int
    EXTERNAL_PORT: int

    # Настройки Redis
    REDIS_HOST: str
    REDIS_PORT: int

    # Настройки SMTP Почты
    SMTP_HOST: str
    SMTP_PORT: int
    SMTP_USER: str
    SMTP_PASSWORD: str
    SMTP_FROM_EMAIL: str
    SECURITY_EMAIL: EmailStr

    # Автоматическое чтение из .env файла в корне проекта
    model_config = SettingsConfigDict(
        env_file="../.env", 
        env_file_encoding="utf-8", 
        extra="ignore"
    )

    # Удобный инструмент для получения строки подключения к БД
    @property
    def database_url(self) -> str:
        return f"postgresql://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"

    # Удобный инструмент для получения строки подключения к Redis
    @property
    def redis_url(self) -> str:
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/0"

# Создаем глобальный объект настроек для использования в других файлах
settings = Settings()
