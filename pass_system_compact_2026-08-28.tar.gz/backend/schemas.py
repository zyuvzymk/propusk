from pydantic import BaseModel, EmailStr, Field
from datetime import date
from typing import List, Optional

# ==============================================================================
# СХЕМЫ ДЛЯ ТАБЛИЧНОЙ ЧАСТИ (ПОСЕТИТЕЛИ И ТРАНСПОРТ)
# ==============================================================================
class VisitorCreate(BaseModel):
    """Схема, которую заполняет подрядчик при добавлении человека"""
    full_name: str = Field(..., min_length=2, max_length=255, description="ФИО сотрудника")
    passport_data: str = Field(..., min_length=10, description="Паспортные данные")
    vehicle_info: Optional[str] = Field(None, max_length=255, description="Марка и госномер авто")

class VisitorResponse(VisitorCreate):
    """Схема, которую бэкенд возвращает при просмотре заявки"""
    id: int
    request_id: int
    is_approved: bool

    class Config:
        from_attributes = True


# ==============================================================================
# СХЕМЫ ДЛЯ ОБЩИХ ДАННЫХ ЗАЯВКИ
# ==============================================================================
class PassRequestCreate(BaseModel):
    """Схема, отправляемая при подаче новой заявки с сайта"""
    company_name: str = Field(..., max_length=255)
    target_object: str = Field(..., max_length=255)
    work_description: str
    
    contact_name: str = Field(..., max_length=255)
    contact_position: str = Field(..., max_length=100)
    contact_phone: str = Field(..., max_length=20)
    contact_email: EmailStr  # Автоматическая валидация формата почты
    
    date_start: date
    date_end: date
    
    # Вложенный список людей из формы
    visitors: List[VisitorCreate] = Field(..., min_items=1, description="Минимум 1 посетитель")

class PassRequestResponse(BaseModel):
    """Схема для выдачи данных заявки в реестр или админку"""
    id: int
    company_name: str
    target_object: str
    contact_name: str
    date_start: date
    date_end: date
    status: str
    reject_reason: Optional[str] = None
    visitors: List[VisitorResponse]
    
    class Config:
        from_attributes = True


# ==============================================================================
# СХЕМЫ ДЛЯ УПРАВЛЕНИЯ ЗАЯВКОЙ (ДЛЯ ПЕПа)
# ==============================================================================
class DateUpdateRequest(BaseModel):
    """Схема для изменения дат ПЕПом (урезание сроков)"""
    date_start: date
    date_end: date

class RejectRequest(BaseModel):
    """Схема для отклонения заявки с опциональной причиной"""
    reason: Optional[str] = Field(None, description="Причина отказа (необязательно)")


# ==============================================================================
# СХЕМЫ ДЛЯ АВТОРИЗАЦИИ (ЛОГИН)
# ==============================================================================
class LoginSchema(BaseModel):
    """Схема для проверки ввода на странице входа"""
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=4)
