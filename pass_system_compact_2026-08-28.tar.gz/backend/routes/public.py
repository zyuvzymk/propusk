from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas

# Создаем изолированный роутер для публичной части сайта
router = APIRouter(prefix="/api/public", tags=["Public Requests"])

@router.post("/request", status_code=status.HTTP_201_CREATED)
def create_pass_request(payload: schemas.PassRequestCreate, db: Session = Depends(get_db)):
    """Прием заявки с формы и запись в базу данных"""
    # 1. Проверяем логику дат
    if payload.date_end < payload.date_start:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Дата окончания не может быть раньше даты начала визита."
        )

    try:
        # 2. Извлекаем данные и создаем основную заявку (без списка людей)
        request_data = payload.model_dump(exclude={'visitors'})
        new_request = models.PassRequest(**request_data, status="pending")
        
        db.add(new_request)
        db.flush()  # Генерируем ID заявки в базе данных для связывания таблиц

        # 3. Записываем строки табличной части (посетители и транспорт)
        for visitor in payload.visitors:
            new_visitor = models.PassVisitor(
                request_id=new_request.id,
                full_name=visitor.full_name,
                passport_data=visitor.passport_data,
                vehicle_info=visitor.vehicle_info,
                is_approved=True
            )
            db.add(new_visitor)

        # 4. Сохраняем всё в PostgreSQL одной чистой транзакцией
        db.commit()
        return {"status": "success", "request_id": new_request.id}

    except Exception as e:
        db.rollback()  # Откатываем изменения в случае непредвиденной ошибки базы
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Ошибка при сохранении заявки в базу данных: {str(e)}"
        )
