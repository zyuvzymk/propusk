import datetime
from sqlalchemy import Column, Integer, String, Date, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from database import Base

class User(Base):
    """Таблица пользователей закрытой части (ПЕП, ДАВ, Охрана)"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False) # 'pep' (ПЕП), 'dav' (ДАВ/Охрана)
    is_active = Column(Boolean, default=True)


class PassRequest(Base):
    """Таблица общих данных заявки на пропуск"""
    __tablename__ = "pass_requests"

    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Данные организации и объекта
    company_name = Column(String(255), nullable=False)
    target_object = Column(String(255), nullable=False)
    work_description = Column(Text, nullable=False)
    
    # Контактное лицо
    contact_name = Column(String(255), nullable=False)
    contact_position = Column(String(100), nullable=False)
    contact_phone = Column(String(20), nullable=False)
    contact_email = Column(String(100), nullable=False)
    
    # Сроки действия
    date_start = Column(Date, nullable=False)
    date_end = Column(Date, nullable=False)
    
    # Статус и управление
    status = Column(String(20), default="pending") # 'pending', 'approved', 'rejected'
    reject_reason = Column(Text, nullable=True)     # Пояснение почему отказано
    
    # Связь с табличной частью (список людей)
    visitors = relationship("PassVisitor", back_populates="request", cascade="all, delete-orphan")


class PassVisitor(Base):
    """Таблица посетителей и автотранспорта (динамические строки заявки)"""
    __tablename__ = "pass_visitors"

    id = Column(Integer, primary_key=True, index=True)
    request_id = Column(Integer, ForeignKey("pass_requests.id", ondelete="CASCADE"), nullable=False)
    
    # Данные человека и машины
    full_name = Column(String(255), nullable=False)
    passport_data = Column(Text, nullable=False)
    vehicle_info = Column(String(255), nullable=True) # Марка, госномер (опционально)
    
    # Флаг для поштучного исключения нарушителей из пропуска ПЕПом
    is_approved = Column(Boolean, default=True)

    # Обратная связь с заявкой
    request = relationship("PassRequest", back_populates="visitors")
