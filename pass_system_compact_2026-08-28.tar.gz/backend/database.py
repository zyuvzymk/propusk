from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from config import settings

# 1. Создаем движок SQLAlchemy, используя URL из нашего config.py
engine = create_engine(
    settings.database_url,
    pool_size=10,
    max_overflow=20
)

# 2. Создаем фабрику сессий для выполнения запросов к БД
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 3. Базовый класс, от которого будут наследоваться все наши таблицы
Base = declarative_base()

# 4. Функция (зависимость) для безопасного открытия/закрытия сессий в запросах
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
